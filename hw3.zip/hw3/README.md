# How to execute

change your working directory to `./hw3/out/production/hw3`

## 3-1

        % java com.poc.CircleApp_3_1                                                                (git)-[master]
        This is circle App
        Enter radius:32.1
        Circumference: 201.69
        Area: 3237.13
        Object count: 1
        continue? (y/n)y
        This is circle App
        Enter radius:123.23
        Circumference: 774.28
        Area: 47707.07
        Object count: 2
        continue? (y/n)n
        Good bye!! See u soon

## 3-2

    % java com.poc.Dice_3_2                                                                     (git)-[master]
    Roll:1
    4
    3
    Craps!!
    continue? (y/n)y
    Roll:2
    5
    2
    Craps!!
    continue? (y/n)y
    Roll:3
    2
    3
    continue? (y/n)y
    Roll:4
    6
    1
    Craps!!
    continue? (y/n)y
    Roll:5
    1
    6
    Craps!!
    continue? (y/n)


## 3-3

    % java com.poc.PigLatin_3_3                                                                 (git)-[master]
    Enter a line to be translated to Pig Latin:
    this program translates english to pig latin


    isthay ogrampray anslatestray englishway otay igpay atinlay
    Translate another line (y/n)?



## 3-4

    % java com.poc.NumberToWordsConverter_3_4                                                   (git)-[master]

    Pls input number that you want to convert it into words: 3842
    three thousand eight hundred forty two
    Convert another number? (y/n)y

    Pls input number that you want to convert it into words: 2001
    two thousand one
    Convert another number? (y/n)y

    Pls input number that you want to convert it into words: 4815
    four thousand eight hundred fifteen
    Convert another number? (y/n)y

    Pls input number that you want to convert it into words: 400
    four hundred
    Convert another number? (y/n)