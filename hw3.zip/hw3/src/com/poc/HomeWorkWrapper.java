package com.poc;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Created by poc on 7/16/16.
 */
public class HomeWorkWrapper {

    private static Scanner rd = new Scanner(System.in);


    void execute() {
        // children should overrite it
    }
}
