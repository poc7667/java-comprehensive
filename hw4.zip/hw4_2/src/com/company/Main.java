package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Customer customer = new Customer();
        System.out.println(customer.getDisplayText());
    }
}
