CD to `out/production/hw4_2`  and run `java com.company.PersonApp`

        ➜  hw4_2 git:(master) ✗ java com.company.PersonApp                                                                            git:(master|✚4
        Welcome to the Person Tester application
        Create customer or employee? (c/e):c
        Enter first name:Poc
        Enter last name:Hsu
        Enter email address:poc7667@gmail.com
        Enter customer number:123
        You entered!Name: Poc Hsu
        Email: poc7667@gmail.com
        Customer Number:123

        Continue? (y/n):y
        Create customer or employee? (c/e):e
        Enter first name:WeiCheng
        Enter last name:Hsu
        Enter email address:poc.hsu@kyperdata.com
        Enter SSN:llaa
        You entered!Name: WeiCheng Hsu
        Email: poc.hsu@kyperdata.com
        Social Security Number:llaa

        Continue? (y/n):n
        See you later!