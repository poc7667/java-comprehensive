package demodayA;
/**
 * 
 */

/**
 * These snippet of examples are put together from
 * either from Java Tutorial examples from Oracle.com
 * or from Java The Complete Reference book of Herbert Schildt
 *
 */
import java.net.*;
import java.io.*;
import java.util.*;

public class URLReader {
	
	public static void showUsage(String str) {
		System.err.println(str);
		System.exit(1);
	}

	public static void testInetAddress(String strDomainName) throws UnknownHostException{
		InetAddress iAddress = InetAddress.getLocalHost();
		System.out.println(iAddress);
		
		iAddress = InetAddress.getByName(strDomainName);
		System.out.println(iAddress);
		
		InetAddress []iArrayAddress = InetAddress.getAllByName(strDomainName);
		for (InetAddress ia: iArrayAddress)
			System.out.println(ia);
	}

	public static void testWhoIs(String hostName) throws IOException {
        Socket s = new Socket("whois.internic.net", 43);
        InputStream in = s.getInputStream();
        OutputStream out = s.getOutputStream();
        hostName = "www.alibaba.com" + "\n";
        byte buf[] = hostName.getBytes();
        out.write(buf);
        
        int c;
        while ((c = in.read()) != -1){
        		System.out.print((char) c);
        }
        s.close();
	}

	//you can only test this if you have a servlet running 
	public static void writingToAnURLConnection(String[] urlStrings) throws Exception {
		if (urlStrings.length != 2) {
            showUsage("Usage:  java Reverse "
                + "http://<location of your servlet/script>"
                + " string_to_reverse");
        }

        String stringToReverse = URLEncoder.encode(urlStrings[1], "UTF-8");

        URL url = new URL(urlStrings[0]);
        URLConnection connection = url.openConnection();
        connection.setDoOutput(true);

        OutputStreamWriter out = new OutputStreamWriter(
                                         connection.getOutputStream());
        out.write("string=" + stringToReverse);
        out.close();

        BufferedReader in = new BufferedReader(
                                    new InputStreamReader(
                                    connection.getInputStream()));
        String decodedString;
        while ((decodedString = in.readLine()) != null) {
            System.out.println(decodedString);
        }
        in.close();
	}
	
	public static void parsingAnURL(String urlString) throws Exception{
        URL aURL = new URL(urlString);

        System.out.println("\n\nprotocol = " + aURL.getProtocol());
        System.out.println("authority = " + aURL.getAuthority());
        System.out.println("host = " + aURL.getHost());
        System.out.println("port = " + aURL.getPort());
        System.out.println("path = " + aURL.getPath());
        System.out.println("query = " + aURL.getQuery());
        System.out.println("filename = " + aURL.getFile());
        System.out.println("ref = " + aURL.getRef());
	}

	public static void testHttpURLConnection(String urlString) throws Exception{
		URL hp = new URL(urlString);
		HttpURLConnection hpCon = (HttpURLConnection) hp.openConnection();
		System.out.println("Request method is " + hpCon.getRequestMethod());
		System.out.println("Request response is " + hpCon.getResponseCode());
		System.out.println("Request response message is " + hpCon.getResponseMessage());
		
		//get a list of the header fields and a set of header keys
		Map<String, List<String>> hdrMap = hpCon.getHeaderFields();
		Set<String> hdrField = hdrMap.keySet();
		System.out.println("\nHere is the header:");
		//display all header keys and values
		for (String k: hdrField) {
			System.out.println("Key: " + k + "  Values: " + hdrMap.get(k));
		}
	}
	
	public static void readingDirectlyFromAURL(String strURL) throws Exception{
       URL oracle = new URL(strURL);
        BufferedReader in = new BufferedReader(
        new InputStreamReader(oracle.openStream()));

        String inputLine;
        while ((inputLine = in.readLine()) != null)
            System.out.println(inputLine);
        in.close();
	}
	
	public static void main(String[] args) throws Exception {
		String [] strArgs= new String[2];
		
		//run one of these methods at a time to understand them better
		testInetAddress("www.apple.com");
		testWhoIs("www.alibaba.com");
		parsingAnURL("http://example.com:80/docs/books/tutorial"
                           + "/index.html?name=networking#DOWNLOADING");
		testHttpURLConnection("http://www.google.com");
		readingDirectlyFromAURL("http://www.oracle.com/");

		//you need a servlet running to test this code, which suppose
		//to reverse a string
/*		
		strArgs[0] = "http://example.com:80/servlet/ReverseServlet";
		strArgs[1] = "Reverse This String";
		writingToAnURLConnection(strArgs); 
*/
	}
}