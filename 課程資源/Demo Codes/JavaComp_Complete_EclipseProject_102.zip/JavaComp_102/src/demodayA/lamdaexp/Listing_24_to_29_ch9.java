package demodayA.lamdaexp;

//Chapter 9: listing 24 of Schildt (c)
////public interface MyIF { 
interface MyIF {
	// This is a "normal" interface method declaration.
	// It does NOT define a default implementation.
	int getNumber();

	// This is a default method. Notice that it provides
	// a default implementation.
	default String getString() {
		return "Default String";
	}
}

// listing 25
// Implement MyIF.
class MyIFImp implements MyIF {
	// Only getNumber() defined by MyIF needs to be implemented.
	// getString() can be allowed to default.
	public int getNumber() {
		return 100;
	}
}

// listing 26
// Use the default method.
// //class DefaultMethodDemo {
public class Listing_24_to_29_ch9 {
	public static void main(String args[]) {

		MyIFImp obj = new MyIFImp();

		// Can call getNumber(), because it is explicitly
		// implemented by MyIFImp:
		System.out.println(obj.getNumber());

		// Can also call getString(), because of default
		// implementation:
		System.out.println(obj.getString());
	}
}

// listing 27
class MyIFImp2 implements MyIF {
	// Here, implementations for both getNumber( ) and getString( ) are
	// provided.
	public int getNumber() {
		return 100;
	}

	public String getString() {
		return "This is a different string.";
	}
}

// listing 28
interface IntStack {
	void push(int item); // store an item

	int pop(); // retrieve an item

	// Because clear( ) has a default, it need not be
	// implemented by a preexisting class that uses IntStack.
	default void clear() {
		System.out.println("clear() not implemented.");
	}
}

// listing 29
////public interface MyIF {
interface MyIF2 {
	// This is a "normal" interface method declaration.
	// It does NOT define a default implementation.
	int getNumber();

	// This is a default method. Notice that it provides
	// a default implementation.
	default String getString() {
		return "Default String";
	}

	// This is a static interface method.
	static int getDefaultNumber() {
		return 0;
	}
}