package demoday8.misc;

public class IOTask implements Runnable{
    @Override
    public void run()
    {
        Thread ct = Thread.currentThread();
        //if you are here, who is running?
        System.out.println(ct.getName() + " started.");
        
        try
        {  
            // Sleep for 2 seconds to simulate an IO task
            // that takes a long time          
            Thread.sleep(2000);    
        }
        catch(InterruptedException e) {}

        System.out.println(ct.getName() + " finished.");
    }
}

