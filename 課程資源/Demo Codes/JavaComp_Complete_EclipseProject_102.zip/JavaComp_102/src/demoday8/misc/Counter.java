package demoday8.misc;

public class Counter implements Runnable
{
    @Override
    public void run()
    {
        Thread ct = Thread.currentThread();        
        int count = 1;
        while (!ct.isInterrupted())
        {
            System.out.println(
                ct.getName() + " count " + count);
            count++;
            try
            {    
                // Sleep for 1 second        
                Thread.sleep(1000); 
            }
            catch(InterruptedException e){
                break;
            }
        }
        System.out.println(ct.getName() + " interrupted.");
    }
}

