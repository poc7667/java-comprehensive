package demoday8.misc;

public class Main_2 {
    public static void main(String[] args)
    {
        Thread t1 = Thread.currentThread();
        System.out.println(t1.getName() + " started.");

        // create the new thread
        Thread t2 = new Thread(new IOTask()); 
                                             
        // start the new thread
        t2.start();
        System.out.println(t1.getName() + " starts " + 
                           t2.getName() + ".");
        
        System.out.println(t1.getName() + " finished.");
        //t2 is out of scope, however, it will keep running
    }
}

