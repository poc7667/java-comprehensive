package demoday8.misc;

public class JoinExample {
	public static void main(String[] args) {

		PrintHello t1 = new PrintHello();
		t1.start();

		try {
			for (int i = 0; i < 50; i++) {
				System.out.println("JoinExample Says: Join! " + i);
				if (i % 5 == 0)
					Thread.yield();
				if (i == 40)
					t1.join();
				// wait for the thread to terminate
			}
		} catch (InterruptedException e) {
			System.out.println("ERROR: Thread was interrupted");
		}

		System.out.println("JoinExample says I am done!");
	}
}
