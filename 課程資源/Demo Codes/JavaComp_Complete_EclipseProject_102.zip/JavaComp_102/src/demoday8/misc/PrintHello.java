package demoday8.misc;

class PrintHello extends Thread {
	   public void run() {
	      for (int i = 0; i < 100; i++) {
		System.out.println("PrintHello says:Hello!"+ i);
				if (i%5==0) Thread.yield();
	      }
	      System.out.println("PrintHello says: I am done! ");
	   }
	}

