package demoday8.misc;

import java.util.Scanner;

public class Main_3 {
    public static void main(String[] args) {
        System.out.println(
            "Press the Enter key to stop counting.");
        Thread counter = new Thread(new Counter());

        // start the counter thread
        counter.start();         
        Scanner sc = new Scanner(System.in);
        String s = "start";

        // wait for the user to press Enter
        while (!s.equals(""))     
            s = sc.nextLine();

        // interrupt the counter thread
        counter.interrupt();   
    }
}
