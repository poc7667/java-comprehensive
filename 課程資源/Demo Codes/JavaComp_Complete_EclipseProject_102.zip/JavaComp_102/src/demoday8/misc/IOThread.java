package demoday8.misc;

public class IOThread extends Thread
{
    @Override
    public void run()
    {
        //if you are here, who is running?			
        System.out.println(this.getName() + " started.");
	
        try
        {            
            // Sleep for 2 seconds to simulate an IO task
            // that takes a long time
            Thread.sleep(2000);   
        }
        catch(InterruptedException e) {} 
       
        System.out.println(this.getName() + " finished.");
    }
}

