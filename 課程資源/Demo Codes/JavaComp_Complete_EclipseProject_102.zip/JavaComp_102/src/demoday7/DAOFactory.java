package demoday7;

public class DAOFactory
{
    // this method maps the ProductDAO interface
    // to the appropriate data storage mechanism
    public static ProductDAO getProductDAO(String strDatabase)
    {
        ProductDAO pDAO; 
    		switch (strDatabase) {
    		case "xml":
    	        pDAO = new ProductXMLFile();
    			break;
    		case "rnd":
    	        pDAO = new ProductRandomFile();
    			break;
    		case "derby":
    	        pDAO = new ProductDB();
    			break;
    		case "txt":
    		default:
    	        pDAO = new ProductTextFile();
    		}
        return pDAO;
    }
}