package demoday7;
public interface ProductDAO extends ProductReader, ProductWriter, ProductConstants
{
    // all methods from the ProductReader and ProductWriter interfaces
    // all static constants from the ProductConstants interface
}