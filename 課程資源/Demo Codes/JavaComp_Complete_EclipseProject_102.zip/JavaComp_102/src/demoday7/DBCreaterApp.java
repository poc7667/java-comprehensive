package demoday7;
import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.*;

public class DBCreaterApp
{
    private static Connection connection = null;

    public static void main(String args[])
    {
 /*
          // set the connection
  
        connection = connect();

        printProducts();
        printFirstProduct();
        printLastProduct();
        printProductByCode("java");

        Product p = new Product("test", "Test Product", 49.50);
        insertProduct(p);
        deleteProduct(p);

        try
        {
            connection.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
  */
        // set the connection
    	  
       connection = newConnect();
       
       try
       {
           resetDatabase(connection);
           printProducts();
          connection.close();
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
    }

    private static Connection connect()
    {
        try
        {
            // if necessary, set the home directory for Derby
        		//by uncommenting these two lines and providing
        	    //the exact directory where MurachDB is located
        	
            //String dbDirectory = "/Users/bineetsharma/db";
            //System.setProperty("derby.system.home", dbDirectory);

        		//However, you don't need to set directory if MurachDB in
        	    //is inside the project directory in the same level as
        	    //as <src> and <bin> folder in Eclipse
 
        	
        	//keep relative path to this project
            String dbDirectory = "Resources";
            System.setProperty("derby.system.home", dbDirectory);

        	// use the DriverManager to create a Connection object
            String dbUrl = "jdbc:derby:MurachDB";
            
            String username = "";
            String password = "";
            Connection connection = DriverManager.getConnection(dbUrl, username, password);

            return connection;

        }
        catch(SQLException e)
        {
            e.printStackTrace();

            return null;
        }
    }

    private static Connection newConnect()
    {
        try
        {
        	//keep relative path to this project
            String dbDirectory = "Resources";
            System.setProperty("derby.system.home", dbDirectory);

        	// use the DriverManager to create a Connection object
            String dbUrl = "jdbc:derby:FinalDB;create=true";
            
            String username = "";
            String password = "";
            Connection connection = DriverManager.getConnection(dbUrl, username, password);

            return connection;

        }
        catch(SQLException e)
        {
            e.printStackTrace();

            return null;
        }
    }

    public static void resetDatabase(Connection c) throws SQLException
    {
        String s            = new String();
        StringBuffer sb = new StringBuffer();
 
        try
        {
            FileReader fr = new FileReader(new File("MurachDBCreate.sql"));
 
            BufferedReader br = new BufferedReader(fr);
 
            while((s = br.readLine()) != null)
            {
                sb.append(s);
            }
            br.close();
 
            // here is our splitter ! We use ";" as a delimiter for each request
            // then we are sure to have well formed statements
            String[] inst = sb.toString().split(";");
 
            Statement st = c.createStatement();
 
            for(int i = 0; i<inst.length; i++)
            {
                // we ensure that there is no spaces before or after the request string
                // in order to not execute empty statements
                if(!inst[i].trim().equals(""))
                {
                    st.executeUpdate(inst[i]);
                    System.out.println(">>"+inst[i]);
                }
            }
   
        }
        catch(Exception e)
        {
            System.out.println("*** Error : "+e.toString());
            System.out.println("*** ");
            System.out.println("*** Error : ");
            e.printStackTrace();
            System.out.println("################################################");
            System.out.println(sb.toString());
        }
 
    }
    public static void printProducts()
    {
        try
        {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM Products");
            Product p = null;

            System.out.println("Product list:");
            while(rs.next())
            {
                String code = rs.getString("ProductCode");
                String description = rs.getString("Description");
                double price = rs.getDouble("Price");

                p = new Product(code, description, price);

                printProduct(p);
            }
            System.out.println();

            rs.close();
            statement.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void printFirstProduct()
    {
        try
        {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM Products");
            if(rs.next())
            {
                // code that uses column names
                String code = rs.getString("ProductCode");
                String description = rs.getString("Description");
                double price = rs.getDouble("Price");
                Product p = new Product(code, description, price);

                System.out.println("First product:");
                printProduct(p);
                System.out.println();
            }
            rs.close();
            statement.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void printLastProduct()
    {
        try
        {
            // Create a scrollable, read-only result set
            Statement statement = connection.createStatement(
              ResultSet.TYPE_SCROLL_INSENSITIVE,
              ResultSet.CONCUR_READ_ONLY);

            // Select all products
            ResultSet rs = statement.executeQuery("SELECT * FROM Products");

            // move to last record
            rs.last();

            // code that uses indexes
            String code = rs.getString("ProductCode");
            String description = rs.getString("Description");
            double price = rs.getDouble("Price");
            Product p = new Product(code, description, price);

            System.out.println("Last product:");
            printProduct(p);
            System.out.println();

            rs.close();
            statement.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void printProductByCode(String productCode)
    {
        try
        {
            PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM Products WHERE ProductCode = ?");
            ps.setString(1, productCode);
            ResultSet rs = ps.executeQuery();

            if(rs.next())
            {
                String code = rs.getString("ProductCode");
                String description = rs.getString("Description");
                double price = rs.getDouble("Price");
                Product p = new Product(code, description, price);

                System.out.println("Product by code: " + productCode);
                printProduct(p);
                System.out.println();
            }

            rs.close();
            ps.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void insertProduct(Product p)
    {
        try
        {
            System.out.println("Insert test: ");

            PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM Products WHERE ProductCode = ?");
            ps.setString(1, p.getCode());
            ResultSet rs = ps.executeQuery();

            if(rs.next())
            {
                System.out.println("This product code already exists: " + p.getCode());
            }
            else
            {
                String insertProduct =
                    "INSERT INTO Products (ProductCode, Description, Price) " +
                    "VALUES (?, ?, ?)";
                PreparedStatement ps2 = connection.prepareStatement(insertProduct);
                ps2.setString(1, p.getCode());
                ps2.setString(2, p.getDescription());
                ps2.setDouble(3, p.getPrice());
                ps2.executeUpdate();
                ps2.close();

                printProduct(p);
            }
            System.out.println();

            rs.close();
            ps.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    private static void deleteProduct(Product p)
    {
        try
        {
            System.out.println("Delete test: ");

            PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM Products WHERE ProductCode = ?");
            ps.setString(1, p.getCode());
            ResultSet rs = ps.executeQuery();

            if(rs.next())
            {
                String deleteProduct =
                    "DELETE FROM Products " +
                    "WHERE ProductCode = ?";
                PreparedStatement ps2 = connection.prepareStatement(deleteProduct);
                ps2.setString(1, p.getCode());
                ps2.executeUpdate();
                ps2.close();
                printProduct(p);
            }
            else
            {
                System.out.println("No record matches this product code: " + p.getCode());
            }
            System.out.println();

            rs.close();
            ps.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    // prints a Product object on a single line
    private static void printProduct(Product p)
    {
        String productString =
            StringUtils.padWithSpaces(p.getCode(), 8) +
            StringUtils.padWithSpaces(p.getDescription(), 44) +
            p.getFormattedPrice();

        System.out.println(productString);
    }
}