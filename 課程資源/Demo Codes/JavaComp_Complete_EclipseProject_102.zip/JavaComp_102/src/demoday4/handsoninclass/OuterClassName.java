package demoday4.handsoninclass;

public class OuterClassName {
	// can contain instance variables and methods
	private int outerInsVariable = 10;
	public int getOuterInstanceVariable() {
		return outerInsVariable;
	}
	
	// can contain static variables and methods
	private static int outerStaticVariable = 100;
	public static int getOuterStaticVariable() {
		return outerStaticVariable;
	}

	//can I access inner class?
	public int getInnerClassData() {
		
		return new StaticInnerClassName().getStaticInnerInstanceVariable();
	}
	
	class InnerClassName {
		// can contain instance variables and methods
		private int innerInsVariable = 20;
		public int getInnerInstanceVariable() {
			return innerInsVariable;
		}
		// can't contain static variables or methods
		/*  
		private static int innerStaticInsVariable = 30;
		public static int getInnerStaticInstanceVariable() {
			return innerStaticInsVariable;
		} 
		*/
		// can access all variables and methods of
		// OuterClass
		public int getOuterInstanceVariable() {
			return outerInsVariable;
		}

		public int getOuterStaticVariableFromInnerClass() {
			int doubleOuterVariable = outerStaticVariable * //private is accessible
					              getOuterStaticVariable();
			return doubleOuterVariable;
		}
	}

	static class StaticInnerClassName {
		// can contain instance variables and methods
		private int staticInnerInsVariable = 30;
		public int getStaticInnerInstanceVariable() {
			return staticInnerInsVariable;
		}
		// can contain static variables and methods
		private static int staticInnerStaticVariable = 300;
		public static int getStaticInnerStaticVariable() {
			return staticInnerStaticVariable;
		}
		// can access static variables and methods of
		// OuterClass
		public int getOuterStaticVariable() {
			int doubleOuterVariable = outerStaticVariable * //private is accessible
					              getOuterStaticVariable();
			return doubleOuterVariable;
		}
		// can't access instance variables or methods --flag of
		// OuterClass
		/*
		public int getOuterInstanceVariableFromInnerStaticClass() {
			int doubleOuterVariable =  outerInsVariable  //not allowed
					              getOuterInstanceVariable(); //not allowed
			return doubleOuterVariable;
		}
		*/
	}
}
