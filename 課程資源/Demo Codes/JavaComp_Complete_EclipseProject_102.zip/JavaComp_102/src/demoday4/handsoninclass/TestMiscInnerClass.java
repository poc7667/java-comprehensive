package demoday4.handsoninclass;

public class TestMiscInnerClass {

public static void main (String[] args){
		//create outer class object
		OuterClassName myOuterClassObject = new OuterClassName();
		
		//can I get inner class data?
		System.out.println("Get data from inner class using outer class: " + 
						myOuterClassObject.getInnerClassData());
		 
		//how do you use non-static inner class?
		OuterClassName.InnerClassName myInnerClassObject =
				myOuterClassObject.new InnerClassName(); 
		
		System.out.println("Accessing Inner Class Instance Variable: " + 
					myInnerClassObject.getInnerInstanceVariable());
		
		System.out.println("Accessing Outer Class Instance Variable: " + 
				myInnerClassObject.getOuterInstanceVariable());
		
		System.out.println("Accessing Outer Class Static Variable: " + 
				myInnerClassObject.getOuterStaticVariableFromInnerClass());

		//how do you use static inner class?
		OuterClassName.StaticInnerClassName myInnerStaticClassObject =
				           new OuterClassName.StaticInnerClassName(); 

		System.out.println("Accessing Inner Class Instance Variable: " + 
				myInnerStaticClassObject.getStaticInnerInstanceVariable());

		System.out.println("Accessing Inner Class Static Variable: " + 
				myInnerStaticClassObject.getStaticInnerStaticVariable());
		
		System.out.println("Accessing Inner Class Static Variable, using class nae: " + 
				OuterClassName.StaticInnerClassName.getStaticInnerStaticVariable());

	}
}
