package demoday4.productmaint;
public interface ProductReader
{
    Product getProduct(String code);
    String getProductsString();
}