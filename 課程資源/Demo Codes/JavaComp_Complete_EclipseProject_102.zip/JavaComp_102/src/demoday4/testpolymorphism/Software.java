package demoday4.testpolymorphism;

public class Software extends Product implements Printable {
	private String version;

	public Software() {
		super();
		version = "";
	}

	public Software(String code, String description, 
			        double price, String version) {
		super(code, description, price);
		this.version = version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getVersion() {
		return version;
	}

	@Override
	public String toString() {
		return super.toString() + "Version:     " 
	                            + version + "\n";
	}

	// implement the Printable interface
	public void print() {
		toString();
	}

}