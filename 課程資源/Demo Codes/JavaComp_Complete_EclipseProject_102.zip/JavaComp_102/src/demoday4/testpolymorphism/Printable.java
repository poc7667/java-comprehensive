package demoday4.testpolymorphism;
public interface Printable
{
    public abstract void print(); 
}