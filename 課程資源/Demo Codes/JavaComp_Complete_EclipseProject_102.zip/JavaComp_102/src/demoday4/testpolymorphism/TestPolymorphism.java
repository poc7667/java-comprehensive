package demoday4.testpolymorphism;

public class TestPolymorphism {

	private static void printMultiple(Printable p, int count)
	{ //Printable is interface
	    for (int i = 0; i < count; i++)
	        p.print();
	}
	
	public static void main(String[] args) {
		//Using overriden methods? Plymorphism (dynamic binding in action)
		Book b = new Book();
		b.setCode("java");
		b.setDescription("Murach's Beginning Java");
		b.setPrice(49.50); b.setAuthor("Steelman");

		Software s = new Software();
		s.setCode("txtp");
		s.setDescription("TextPad");
		s.setPrice(27.00); s.setVersion("4.7.3");

		Product p;    //p is not yet an object, just a reference 
		p = b;        //implicit casting.  Subclass can be assigned
		              //to superclass, now p is pointing to object
		System.out.println(p.toString());  // calls toString from 
		                                   // the Book class
		p = s;
		System.out.println(p.toString());  // calls toString from 
		                                   // the Software class
		//Code that displays an object’s type
		Product p1 = new Book(); // create a Book object and 
						        // assign it to a Product variable
		Class c = p1.getClass();  // get the Class object for the product
        
		// print the object type
		System.out.println("Class name: " + c.getName());
   
		//Code that tests an object’s type
		Product p2 = new Book();  // create a Book object
		if (p2.getClass().getName().equals("testpolymorphism.Book"))
		    System.out.println("This is a Book object");

		//An easier way to test an object’s type
		Product p3 = new Book();  // create a Book object
		if (p3 instanceof Book)
		    System.out.println("This is a Book Instance");

		System.out.println();
		
		//Casting Objects Example
		Book b4 = new Book();

		b4.setCode("java");
		b4.setDescription("Murach's Beginning Java");
		b4.setPrice(49.50);
		b4.setAuthor("Steelman");

		//change the assignment to Base class
		Product p4 = new Software();  //upcasting is implicit

		p4.setCode("txtp");
		p4.setDescription("TextPad");
		p4.setPrice(27.00); //can I do this? p.setVersion("4.7.3");

		Software s4;
		s4 = (Software) p4;  		//downcasting needs to be explicit

		s4.setVersion("4.7.3"); //is it error?compile/run time?
		System.out.println(s4.toString()); // calls Software version 

		//Casting Objects (cont.), Can we do this?
		
		Book b5 = new Book();

		b5.setCode("java");
		b5.setDescription("Murach's Beginning Java");
		b5.setPrice(49.50);
		b5.setAuthor("Steelman");

		//create the object using base class
		Product p5 = new Product(); 

		p5.setCode("txtp");
		p5.setDescription("TextPad");
		p5.setPrice(27.00);

		Software s5;
		/*
	    //this gives ClassCastException, uncomment to test it out
		s5 = (Software) p5;     //downcasting needs to be explicit
 								//is it error?compile/run time?
		s5.setVersion("4.7.3"); 						
		System.out.println(s5.toString()); 
		*/
		
		//Casting example that use the Product and Book classes
		Book b6 = new Book();
		b6.setCode("java");
		b6.setDescription("Murach's Beginning Java");
		b6.setAuthor("Andrea Steelman");
		b6.setPrice(49.50);

		Product p6 = b6;            // cast Book object to a
		                          // Product object
		p6.setDescription("Test"); // OK - method in Product class
		//p6.setAuthor("Test");    // not OK - method not in 
		                          // Product class

		b6 = (Book) p6;             // cast the Product object back 
		                          // to a Book object
		b6.setAuthor("Test");      // OK - method in Book class

		Product p7 = new Product();
		
        /* //this gives ClassCastException, uncomment to test it out
		Book b7 = (Book) p7;    // will throw ClassCastException
		                        // because p7 is a Product object 
		// not a Book object.  It is like child knows about parent, 
		//but parent don’t know how many children they have
		*/
		
		//Code that passes a book object to the method
		Book book = new Book("java", "Murach's Beginning Java", 
				             49.50, "4.7.3");
		printMultiple(book, 2); //Book is a class

		//Code that passes a book object to the method using intervace
		Printable printable = new Book("java", "Murach's Beginning Java", 
				             49.50, "4.7.3");
		printMultiple(printable, 2); //printable is an interface
	}
}
