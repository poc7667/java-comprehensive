package com.poc;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Area_1_1 areaCalculator = new Area_1_1();
        areaCalculator.start();

        Grade_1_2 grade = new Grade_1_2();
        grade.kick();

        Temprature_1_3 temp = new Temprature_1_3();
        temp.kick();

        Travel_1_4 travel = new Travel_1_4();
        travel.kick();

        Coin_1_5 coin = new Coin_1_5();
        coin.kick();

    }
}
